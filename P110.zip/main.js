https://teachablemachine.withgoogle.com/models/WB2vYCDjF/
